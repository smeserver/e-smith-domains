#!/usr/bin/perl -w 

#----------------------------------------------------------------------
# $Id: domains.pm,v 1.1 2005/08/25 17:51:33 charlieb Exp $
#----------------------------------------------------------------------
# copyright (C) 1999-2005 Mitel Networks Corporation
# Copyright 2005 Gordon Rowell <gordonr@gormand.com.au>
# 
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA
#----------------------------------------------------------------------
package    esmith::FormMagick::Panel::domains;

use strict;

use esmith::FormMagick;
use esmith::AccountsDB;
use esmith::DomainsDB;
use esmith::ConfigDB;
use Exporter;
use Carp qw(verbose);

use HTML::Tabulate;

our @ISA = qw(esmith::FormMagick Exporter);

our @EXPORT = qw();

our $VERSION = sprintf '%d.%03d', q$Revision: 1.1 $ =~ /: (\d+).(\d+)/;

our $db = esmith::ConfigDB->open();
our $ddb = esmith::DomainsDB->open();
our $adb = esmith::AccountsDB->open_ro();

our $REGEXP_DOMAIN = qq([a-zA-Z0-9\-\.]+);

=pod 

=head1 NAME

esmith::FormMagick::Panels::domains - Domains panel functions

=head1 SYNOPSIS

use esmith::FormMagick::Panels::domains;

my $panel = esmith::FormMagick::Panel::domains->new();
$panel->display();

=head1 DESCRIPTION


=head2 new();

Exactly as for esmith::FormMagick

=begin testing

$ENV{ESMITH_DOMAINS_DB} = "10e-smith-base/domains.conf";
$ENV{ESMITH_CONFIG_DB} = "10e-smith-base/configuration.conf";

open DATA, "echo '<form></form>'|";
use_ok('esmith::FormMagick::Panel::domains');
use vars qw($panel);
ok($panel = esmith::FormMagick::Panel::domains->new(), 
"Create panel object");
close DATA;
isa_ok($panel, 'esmith::FormMagick::Panel::domains');
$panel->{cgi} = CGI->new();
$panel->parse_xml();

{ package esmith::FormMagick::Panel::domains;
our $domainsdb;
::isa_ok($domainsdb, 'esmith::DomainsDB');
}

=end testing

=cut

sub new {
    shift;
    my $self = esmith::FormMagick->new();
    $self->{calling_package} = (caller)[0];
    bless $self;
    return $self;
}

=head1 HTML GENERATION ROUTINES

Routines for generating chunks of HTML needed by the panel.

=head2 print_domains_table

Prints out the domains table on the front page.

=cut

sub print_domains_table
{
    my $self = shift;
    my $q = $self->{cgi};

    my $domains_table = 
    {
       title => $self->localise('CURRENT_LIST_OF_DOMAINS'),
       
       stripe => '#D4D0C8',

       fields => [ qw(Domain Description Content Nameservers Modify Remove) ],

       labels => 1,

       field_attr => {
                       Domain => { label =>
		       $self->localise('DOMAIN_NAME_LABEL') },
		       Description => { label =>
		       $self->localise('DESCRIPTION_LABEL') },
		       Content => { label => $self->localise('CONTENT_LABEL') },
		       Nameservers => { label => $self->localise('LABEL_NAMESERVERS') },
		       Modify => { label => $self->localise('MODIFY'),
		    		 link => \&modify_link },
		       Remove => { label => $self->localise('REMOVE'),
		    		 link => \&remove_link,
				 value => \&remove_value }, 
                                            },
           };

    my @data = ();

    my $modify = $self->localise('MODIFY');
    my $remove = $self->localise('REMOVE');

    for ($ddb->domains)
    {
        my $ns = $_->prop('Nameservers') || 'internet';

        push @data, 
            { Domain => $_->key, $_->props, 
              Modify => $modify, Remove => $remove,
              Nameservers => $self->localise($ns),
            }
    }

    my $t = HTML::Tabulate->new($domains_table);

    $t->render(\@data, $domains_table);
}

sub modify_link
{
    my ($data_item, $row, $field) = @_;

    return "domains?page=0&page_stack=&Next=Next&Domain=" .
            $row->{Domain} . "&wherenext=DOMAINS_PAGE_MODIFY";
}

sub remove_link
{
    my ($data_item, $row, $field) = @_;

    return undef if (($row->{Removable} || "yes") eq "no");

    return "domains?page=0&page_stack=&Next=Next&Domain=" .
            $row->{Domain} . "&wherenext=DOMAINS_PAGE_REMOVE";
}

sub remove_value
{
    my ($data_item, $row, $field) = @_;

    return "" if (($row->{Removable} || "yes") eq "no");

    return $row->{Remove};
}

sub get_content_options
{
    my $self = shift;

    # We do some subversion here to localize the label of "Primary".
    my %options = map { $_->key => $_->prop('Name') }
      grep { $_->key ne "Primary" } $adb->ibays;

    $options{'Primary'} = $self->localise('PRIMARY_SITE');

    return \%options
}

sub get_content_value
{
    my $self = shift;
    my $q = $self->{cgi};

    my $domain = $q->param('Domain') || undef;

    return $domain ? $ddb->get_prop($domain, 'Content') : 'Primary';
}

sub get_description_value
{
    my $self = shift;
    my $q = $self->{cgi};

    my $domain = $q->param('Domain') || undef;

    return $ddb->get_prop($domain, 'Description');
}

sub get_nameserver_options
{
    my $self = shift;
    my $q = $self->{cgi};

    my $domain = $q->param('Domain') || undef;

    my @options = qw(localhost internet);
    
    push @options, 'corporate' if ($db->get_prop('dnscache', 'Forwarder'));

    my $ns = ($ddb->get_prop($domain, 'Nameservers') || 'internet');

    push @options, $ns unless scalar grep { /^$ns$/ } @options;
    
    return \@options;
}

sub get_nameserver_value
{
    my $self = shift;
    my $q = $self->{cgi};

    my $domain = $q->param('Domain') || undef;

    return ($ddb->get_prop($domain, 'Nameservers') || 'internet');
}

sub validate_Domain
{
    my $self = shift;
    my $domain = lc shift;

    return ($domain =~ /^($REGEXP_DOMAIN)$/) ? 'OK' :
                            'DOMAIN_NAME_VALIDATION_ERROR';
}

sub validate_Description
{
    # XXX - FIXME - NOTREACHED
    # We used to use the Description in the Appletalk volume name
    # which meant it needed validation. I don't see any reason to
    # do this any more
    
    my $self = shift;
    my $description = shift;

    return ($description =~ /^([\-\'\w][\-\'\w\s\.]*)$/) ? 'OK' :
                    'DOMAIN_DESCRIPTION_VALIDATION_ERROR';
}

sub ip_number_or_blank
{
    # XXX - FIXME - we should push this down into CGI::FormMagick

    my $self = shift;
    my $ip = shift;

    if (!defined($ip) || $ip eq "")
    {
        return 'OK';
    }
                                    
    return CGI::FormMagick::Validator::ip_number($self, $ip);
}

=head2 get_prop ITEM PROP

A simple accessor for esmith::ConfigDB::Record::prop

=cut

sub get_prop
{
    # XXX - FIXME - we should push this down to esmith::FormMagick

    my ($self, $item, $prop, $default) = @_;

    return $db->get_prop($item, $prop) || $default;
}

sub modify_dns
{
    my ($fm) = @_;
    my $q = $fm->{'cgi'};

    my $forwarder = $q->param('Forwarder') || '';
    my $forwarder2 = $q->param('Forwarder2') || '';

    ($forwarder, $forwarder2) = ($forwarder2, '')
        if ($forwarder2 and not $forwarder);

    $db->set_prop('dnscache', 'Forwarder', $forwarder);
    $db->set_prop('dnscache', 'Forwarder2', $forwarder2);

    unless ( system( "/sbin/e-smith/signal-event", "dns-update" ) == 0 )
    {
        $fm->error('ERROR_UPDATING');
        return undef;
    }

    return $fm->success('SUCCESS');
}

sub create_modify_domain
{
    my ($fm, $action) = @_;
    my $q = $fm->{'cgi'};

    my $domain = $q->param('Domain');

    $domain = $1 if ($domain =~ /^($REGEXP_DOMAIN)$/);

    unless ($domain)
    {
        $fm->error($action eq 'create' ? 'ERROR_CREATING_DOMAIN'
                                        : 'ERROR_MODIFYING_DOMAIN');
        return undef;
    }

    my $rec = $ddb->get($domain);

    if ($rec and $action eq 'create')
    {
        $fm->error('DOMAIN_IN_USE_ERROR');
        return undef;
    }

    if (not $rec and $action eq 'modify')
    {
        $fm->error('NONEXISTENT_DOMAIN_ERROR');
        return undef;
    }

    $rec ||= $ddb->new_record($domain, { type => 'domain' });

    my %props;

    $props{$_} = $q->param($_) for ( qw(Content Description Nameservers) );

    $rec->merge_props(%props);

    my $status = system( "/sbin/e-smith/signal-event", 
                        "domain-$action", "$domain" );

    if ($status)
    {
        $fm->error($action eq 'create' ? 'ERROR_CREATING_DOMAIN'
                                       : 'ERROR_MODIFYING_DOMAIN');
        return undef;
    }

    $fm->success($action eq 'create' ? 'SUCCESSFULLY_CREATED'
                                     : 'SUCCESSFULLY_MODIFIED');
}

sub delete_domain
{
    my ($fm, $action) = @_;
    my $q = $fm->{'cgi'};

    my $domain = $q->param('Domain');

    $domain = $1 if ($domain =~ /^($REGEXP_DOMAIN)$/);

    unless ($domain)
    {
        $fm->error('ERROR_WHILE_REMOVING_DOMAIN');
        return undef;
    }

    my $rec = $ddb->get($domain);

    if (not $rec)
    {
        $fm->error('NONEXISTENT_DOMAIN_ERROR');
        return undef;
    }

    $rec->set_prop('type', 'domain-deleted');

    if (system("/sbin/e-smith/signal-event", "domain-delete", "$domain") == 0)
    {
        $rec->delete;
        return $fm->success('SUCCESSFULLY_DELETED');
    }

    return $fm->error('ERROR_WHILE_REMOVING_DOMAIN');
}
1;
